from flask import Flask, render_template, request, redirect, url_for, jsonify, send_file
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os
import pandas as pd
import matplotlib
matplotlib.use('Agg')  # Usar backend não interativo
import matplotlib.pyplot as plt
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import xlsxwriter
import io
import json

# Configuração do aplicativo Flask
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///diarias.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'chave_secreta_para_controle_diarias'

# Inicialização do banco de dados
db = SQLAlchemy(app)

# Definição dos modelos de dados
class Funcionario(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    diarias = db.relationship('Diaria', backref='funcionario', lazy=True)
    
    def __repr__(self):
        return f'<Funcionario {self.nome}>'

class Diaria(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    data = db.Column(db.Date, nullable=False)
    valor = db.Column(db.Float, nullable=False)
    local = db.Column(db.String(200), nullable=False)
    funcionario_id = db.Column(db.Integer, db.ForeignKey('funcionario.id'), nullable=False)
    data_registro = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Diaria {self.data} - {self.funcionario.nome}>'

# Rotas do aplicativo
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/funcionarios')
def listar_funcionarios():
    funcionarios = Funcionario.query.all()
    return render_template('funcionarios.html', funcionarios=funcionarios)

@app.route('/funcionarios/novo', methods=['GET', 'POST'])
def novo_funcionario():
    if request.method == 'POST':
        nome = request.form['nome']
        funcionario = Funcionario(nome=nome)
        db.session.add(funcionario)
        db.session.commit()
        return redirect(url_for('listar_funcionarios'))
    return render_template('novo_funcionario.html')

@app.route('/diarias')
def listar_diarias():
    diarias = Diaria.query.order_by(Diaria.data.desc()).all()
    funcionarios = Funcionario.query.all()
    return render_template('diarias.html', diarias=diarias, funcionarios=funcionarios)

@app.route('/diarias/nova', methods=['GET', 'POST'])
def nova_diaria():
    if request.method == 'POST':
        data = datetime.strptime(request.form['data'], '%Y-%m-%d').date()
        valor = float(request.form['valor'])
        local = request.form['local']
        funcionario_id = int(request.form['funcionario_id'])
        
        diaria = Diaria(
            data=data,
            valor=valor,
            local=local,
            funcionario_id=funcionario_id
        )
        
        db.session.add(diaria)
        db.session.commit()
        return redirect(url_for('listar_diarias'))
    
    funcionarios = Funcionario.query.all()
    return render_template('nova_diaria.html', funcionarios=funcionarios)

@app.route('/dashboard')
def dashboard():
    funcionarios = Funcionario.query.all()
    diarias = Diaria.query.all()
    return render_template('dashboard.html', funcionarios=funcionarios, diarias=diarias, now=datetime.now())

@app.route('/api/dados_dashboard')
def dados_dashboard():
    # Dados para o gráfico de diárias por funcionário
    funcionarios = Funcionario.query.all()
    dados_funcionarios = []
    
    for funcionario in funcionarios:
        total_diarias = sum(diaria.valor for diaria in funcionario.diarias)
        dados_funcionarios.append({
            'nome': funcionario.nome,
            'total': total_diarias
        })
    
    # Dados para o gráfico de diárias por mês
    diarias = Diaria.query.all()
    dados_por_mes = {}
    
    for diaria in diarias:
        mes_ano = diaria.data.strftime('%m/%Y')
        if mes_ano in dados_por_mes:
            dados_por_mes[mes_ano] += diaria.valor
        else:
            dados_por_mes[mes_ano] = diaria.valor
    
    dados_mensais = [{'mes': mes, 'total': total} for mes, total in dados_por_mes.items()]
    
    return jsonify({
        'por_funcionario': dados_funcionarios,
        'por_mes': dados_mensais,
        'diarias': [{'id': d.id, 'valor': d.valor} for d in diarias]
    })

@app.route('/relatorios')
def relatorios():
    funcionarios = Funcionario.query.all()
    return render_template('relatorios.html', funcionarios=funcionarios, now=datetime.now())

@app.route('/relatorios/gerar', methods=['POST'])
def gerar_relatorio():
    tipo_relatorio = request.form['tipo']
    formato = request.form['formato']
    data_inicio = datetime.strptime(request.form['data_inicio'], '%Y-%m-%d').date()
    data_fim = datetime.strptime(request.form['data_fim'], '%Y-%m-%d').date()
    funcionario_id = request.form.get('funcionario_id', None)
    
    # Consulta base
    query = Diaria.query.filter(Diaria.data >= data_inicio, Diaria.data <= data_fim)
    
    # Filtrar por funcionário se especificado
    if funcionario_id and funcionario_id != 'todos':
        query = query.filter(Diaria.funcionario_id == int(funcionario_id))
    
    diarias = query.order_by(Diaria.data).all()
    
    # Preparar dados para o relatório
    dados = []
    for diaria in diarias:
        dados.append({
            'data': diaria.data.strftime('%d/%m/%Y'),
            'funcionario': diaria.funcionario.nome,
            'valor': diaria.valor,
            'local': diaria.local
        })
    
    # Gerar relatório no formato solicitado
    if formato == 'pdf':
        return gerar_pdf(dados, tipo_relatorio, data_inicio, data_fim)
    elif formato == 'excel':
        return gerar_excel(dados, tipo_relatorio, data_inicio, data_fim)
    else:
        return "Formato não suportado", 400

def gerar_pdf(dados, tipo_relatorio, data_inicio, data_fim):
    buffer = io.BytesIO()
    p = canvas.Canvas(buffer, pagesize=letter)
    
    # Título
    p.setFont("Helvetica-Bold", 16)
    p.drawString(30, 750, f"Relatório de Diárias - {tipo_relatorio.capitalize()}")
    
    # Período
    p.setFont("Helvetica", 12)
    p.drawString(30, 730, f"Período: {data_inicio.strftime('%d/%m/%Y')} a {data_fim.strftime('%d/%m/%Y')}")
    
    # Cabeçalho da tabela
    p.setFont("Helvetica-Bold", 12)
    p.drawString(30, 700, "Data")
    p.drawString(120, 700, "Funcionário")
    p.drawString(300, 700, "Local")
    p.drawString(500, 700, "Valor (R$)")
    
    # Linha separadora
    p.line(30, 690, 550, 690)
    
    # Dados da tabela
    y = 670
    total = 0
    p.setFont("Helvetica", 10)
    
    for item in dados:
        p.drawString(30, y, item['data'])
        p.drawString(120, y, item['funcionario'])
        p.drawString(300, y, item['local'])
        p.drawString(500, y, f"R$ {item['valor']:.2f}")
        
        total += item['valor']
        y -= 20
        
        # Nova página se necessário
        if y < 50:
            p.showPage()
            p.setFont("Helvetica-Bold", 12)
            p.drawString(30, 750, f"Relatório de Diárias - {tipo_relatorio.capitalize()} (continuação)")
            p.setFont("Helvetica", 10)
            y = 730
    
    # Total
    p.line(30, y - 10, 550, y - 10)
    p.setFont("Helvetica-Bold", 12)
    p.drawString(400, y - 30, f"Total: R$ {total:.2f}")
    
    p.showPage()
    p.save()
    
    buffer.seek(0)
    return send_file(
        buffer,
        as_attachment=True,
        download_name=f"relatorio_diarias_{data_inicio.strftime('%Y%m%d')}_{data_fim.strftime('%Y%m%d')}.pdf",
        mimetype='application/pdf'
    )

def gerar_excel(dados, tipo_relatorio, data_inicio, data_fim):
    buffer = io.BytesIO()
    
    # Criar workbook e worksheet
    workbook = xlsxwriter.Workbook(buffer)
    worksheet = workbook.add_worksheet()
    
    # Formatos
    titulo_format = workbook.add_format({'bold': True, 'font_size': 14})
    cabecalho_format = workbook.add_format({'bold': True, 'border': 1})
    data_format = workbook.add_format({'border': 1})
    moeda_format = workbook.add_format({'border': 1, 'num_format': 'R$ #,##0.00'})
    total_format = workbook.add_format({'bold': True, 'num_format': 'R$ #,##0.00'})
    
    # Título
    worksheet.write(0, 0, f"Relatório de Diárias - {tipo_relatorio.capitalize()}", titulo_format)
    worksheet.write(1, 0, f"Período: {data_inicio.strftime('%d/%m/%Y')} a {data_fim.strftime('%d/%m/%Y')}")
    
    # Cabeçalhos
    worksheet.write(3, 0, "Data", cabecalho_format)
    worksheet.write(3, 1, "Funcionário", cabecalho_format)
    worksheet.write(3, 2, "Local", cabecalho_format)
    worksheet.write(3, 3, "Valor (R$)", cabecalho_format)
    
    # Ajustar largura das colunas
    worksheet.set_column(0, 0, 15)
    worksheet.set_column(1, 1, 25)
    worksheet.set_column(2, 2, 30)
    worksheet.set_column(3, 3, 15)
    
    # Dados
    row = 4
    total = 0
    
    for item in dados:
        worksheet.write(row, 0, item['data'], data_format)
        worksheet.write(row, 1, item['funcionario'], data_format)
        worksheet.write(row, 2, item['local'], data_format)
        worksheet.write(row, 3, item['valor'], moeda_format)
        
        total += item['valor']
        row += 1
    
    # Total
    worksheet.write(row + 1, 2, "Total:", cabecalho_format)
    worksheet.write(row + 1, 3, total, total_format)
    
    workbook.close()
    
    buffer.seek(0)
    return send_file(
        buffer,
        as_attachment=True,
        download_name=f"relatorio_diarias_{data_inicio.strftime('%Y%m%d')}_{data_fim.strftime('%Y%m%d')}.xlsx",
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )

# Inicialização do banco de dados
with app.app_context():
    db.create_all()
    
    # Adicionar funcionários iniciais se o banco estiver vazio
    if not Funcionario.query.first():
        funcionarios = [
            "Funcionário 1",
            "Funcionário 2",
            "Funcionário 3",
            "Funcionário 4",
            "Funcionário 5",
            "Funcionário 6",
            "Funcionário 7",
            "Funcionário 8",
            "Funcionário 9",
            "Funcionário 10"
        ]
        
        for nome in funcionarios:
            db.session.add(Funcionario(nome=nome))
        
        db.session.commit()

# Iniciar o aplicativo
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=False)
