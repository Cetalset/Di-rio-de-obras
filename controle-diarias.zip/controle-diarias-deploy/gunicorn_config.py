import gunicorn

# Arquivo de configuração para o Gunicorn
bind = "0.0.0.0:8080"
workers = 4
timeout = 120
