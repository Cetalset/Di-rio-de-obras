// Funções para filtros avançados
function aplicarFiltrosAvancados() {
    const filtroData = document.getElementById('filtroData').value;
    const filtroFuncionario = document.getElementById('filtroFuncionario').value;
    const filtroLocal = document.getElementById('filtroLocal').value;
    const filtroValorMin = document.getElementById('filtroValorMin').value;
    const filtroValorMax = document.getElementById('filtroValorMax').value;
    
    const tabela = document.getElementById('tabelaDados');
    const linhas = tabela.getElementsByTagName('tr');
    
    for (let i = 1; i < linhas.length; i++) {
        let visivel = true;
        const celulas = linhas[i].getElementsByTagName('td');
        
        if (celulas.length > 0) {
            // Filtro por data
            if (filtroData && celulas[0].textContent.indexOf(filtroData) === -1) {
                visivel = false;
            }
            
            // Filtro por funcionário
            if (filtroFuncionario && filtroFuncionario !== 'todos' && 
                celulas[1].textContent !== filtroFuncionario) {
                visivel = false;
            }
            
            // Filtro por local
            if (filtroLocal && celulas[2].textContent.toLowerCase().indexOf(filtroLocal.toLowerCase()) === -1) {
                visivel = false;
            }
            
            // Filtro por valor mínimo
            if (filtroValorMin) {
                const valor = parseFloat(celulas[3].textContent.replace('R$ ', '').replace(',', '.'));
                if (valor < parseFloat(filtroValorMin)) {
                    visivel = false;
                }
            }
            
            // Filtro por valor máximo
            if (filtroValorMax) {
                const valor = parseFloat(celulas[3].textContent.replace('R$ ', '').replace(',', '.'));
                if (valor > parseFloat(filtroValorMax)) {
                    visivel = false;
                }
            }
        }
        
        linhas[i].style.display = visivel ? '' : 'none';
    }
    
    atualizarTotais();
}

function atualizarTotais() {
    const tabela = document.getElementById('tabelaDados');
    const linhas = tabela.getElementsByTagName('tr');
    let totalDiarias = 0;
    let totalValor = 0;
    
    for (let i = 1; i < linhas.length; i++) {
        if (linhas[i].style.display !== 'none') {
            const celulas = linhas[i].getElementsByTagName('td');
            if (celulas.length > 0) {
                totalDiarias++;
                const valor = parseFloat(celulas[3].textContent.replace('R$ ', '').replace(',', '.'));
                totalValor += valor;
            }
        }
    }
    
    document.getElementById('totalDiariasFiltradas').textContent = totalDiarias;
    document.getElementById('totalValorFiltrado').textContent = 'R$ ' + totalValor.toFixed(2);
}

// Funções para exportação de relatórios
function prepararExportacaoPDF() {
    // Mostrar indicador de carregamento
    document.getElementById('loadingIndicator').style.display = 'block';
    
    // Submeter o formulário para gerar PDF
    document.getElementById('formRelatorio').submit();
    
    // Esconder indicador após um tempo
    setTimeout(function() {
        document.getElementById('loadingIndicator').style.display = 'none';
    }, 3000);
}

// Funções para dashboard avançado
function atualizarDashboard() {
    fetch('/api/dados_dashboard')
        .then(response => response.json())
        .then(data => {
            atualizarGraficoFuncionarios(data.por_funcionario);
            atualizarGraficoMensal(data.por_mes);
            atualizarIndicadores(data);
        })
        .catch(error => console.error('Erro ao atualizar dashboard:', error));
}

function atualizarIndicadores(data) {
    // Calcular totais
    let totalDiarias = 0;
    let totalValor = 0;
    
    data.por_funcionario.forEach(item => {
        totalValor += item.total;
    });
    
    // Contar total de diárias
    if (data.diarias) {
        totalDiarias = data.diarias.length;
    }
    
    // Atualizar elementos na página
    document.getElementById('totalDiarias').textContent = totalDiarias;
    document.getElementById('valorTotal').textContent = 'R$ ' + totalValor.toFixed(2);
    document.getElementById('totalFuncionarios').textContent = data.por_funcionario.length;
}

// Inicialização de componentes avançados
document.addEventListener('DOMContentLoaded', function() {
    // Inicializar filtros avançados se existirem
    const btnFiltrarAvancado = document.getElementById('btnFiltrarAvancado');
    if (btnFiltrarAvancado) {
        btnFiltrarAvancado.addEventListener('click', aplicarFiltrosAvancados);
    }
    
    // Inicializar exportação se existir
    const btnExportarPDF = document.getElementById('btnExportarPDF');
    if (btnExportarPDF) {
        btnExportarPDF.addEventListener('click', prepararExportacaoPDF);
    }
    
    // Atualizar dashboard se estiver na página
    if (document.getElementById('funcionarioChart') && document.getElementById('mesChart')) {
        atualizarDashboard();
        
        // Atualizar a cada 5 minutos
        setInterval(atualizarDashboard, 300000);
    }
});
