// Funções para o dashboard
document.addEventListener('DOMContentLoaded', function() {
    // Verificar se estamos na página de dashboard
    if (document.getElementById('funcionarioChart') && document.getElementById('mesChart')) {
        carregarDadosDashboard();
    }
    
    // Inicializar tooltips do Bootstrap
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });
    
    // Inicializar datepickers se existirem
    if (document.querySelectorAll('.datepicker').length > 0) {
        document.querySelectorAll('.datepicker').forEach(function(el) {
            el.addEventListener('focus', function() {
                this.type = 'date';
            });
            el.addEventListener('blur', function() {
                if (!this.value) {
                    this.type = 'text';
                }
            });
        });
    }
});

function carregarDadosDashboard() {
    fetch('/api/dados_dashboard')
        .then(response => response.json())
        .then(data => {
            criarGraficoFuncionarios(data.por_funcionario);
            criarGraficoMensal(data.por_mes);
        })
        .catch(error => console.error('Erro ao carregar dados do dashboard:', error));
}

function criarGraficoFuncionarios(dados) {
    const ctx = document.getElementById('funcionarioChart').getContext('2d');
    
    // Extrair nomes e valores
    const nomes = dados.map(item => item.nome);
    const valores = dados.map(item => item.total);
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: nomes,
            datasets: [{
                label: 'Total de Diárias (R$)',
                data: valores,
                backgroundColor: 'rgba(13, 110, 253, 0.7)',
                borderColor: 'rgba(13, 110, 253, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return 'R$ ' + value.toFixed(2);
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'R$ ' + context.raw.toFixed(2);
                        }
                    }
                }
            }
        }
    });
}

function criarGraficoMensal(dados) {
    const ctx = document.getElementById('mesChart').getContext('2d');
    
    // Extrair meses e valores
    const meses = dados.map(item => item.mes);
    const valores = dados.map(item => item.total);
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: meses,
            datasets: [{
                label: 'Total Mensal (R$)',
                data: valores,
                backgroundColor: 'rgba(40, 167, 69, 0.2)',
                borderColor: 'rgba(40, 167, 69, 1)',
                borderWidth: 2,
                tension: 0.3,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return 'R$ ' + value.toFixed(2);
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'R$ ' + context.raw.toFixed(2);
                        }
                    }
                }
            }
        }
    });
}

// Função para confirmar exclusão
function confirmarExclusao(id, tipo) {
    if (confirm(`Tem certeza que deseja excluir este ${tipo}?`)) {
        window.location.href = `/${tipo}s/excluir/${id}`;
    }
}

// Função para filtrar tabelas
function filtrarTabela() {
    const input = document.getElementById('filtroTabela');
    const filtro = input.value.toUpperCase();
    const tabela = document.getElementById('tabelaDados');
    const linhas = tabela.getElementsByTagName('tr');
    
    for (let i = 1; i < linhas.length; i++) {
        let visivel = false;
        const celulas = linhas[i].getElementsByTagName('td');
        
        for (let j = 0; j < celulas.length; j++) {
            const texto = celulas[j].textContent || celulas[j].innerText;
            if (texto.toUpperCase().indexOf(filtro) > -1) {
                visivel = true;
                break;
            }
        }
        
        linhas[i].style.display = visivel ? '' : 'none';
    }
}
